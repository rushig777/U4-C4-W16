
export const GET_DATA ="GET_DATA"
export const HIGH_TO_LOW ="HIGH_TO_LOW"
export const LOW_TO_HIGH ="LOW_TO_HIGH"
export const MENDATA="MENDATA"
export const WOMENDATA="WOMENDATA"
export const KIDSDATA="KIDSDATA"
export const HOMEDECOR="HOMEDECOR"
