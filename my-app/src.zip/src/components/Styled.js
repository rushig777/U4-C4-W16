import styled from "styled-components";

export const Grid = styled.div``;

export const Select = styled.select``;

export const Flex = styled.div``;
